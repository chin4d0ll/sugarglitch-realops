
# OSINT Toolkit - Power Tools Collection

## 1. Username / Profile Enumeration
- Maigret: `maigret username`
- Nexfil: `python3 nexfil.py -u username`
- Socialscan: `socialscan username`

## 2. Social Media Analytics
- Instaloader: `instaloader profile username`
- Tinfoleak: `python3 tinfoleak.py -u username`

## 3. Email Intelligence
- Holehe: `holehe email@example.com`

## 4. Domain / Infrastructure
- Amass: `amass enum -d domain.com`
- theHarvester: `theHarvester -d domain.com -b all`
- Shodan: `shodan search "alxtrading"`

## 5. Metadata & Link Intelligence
- ExifTool: `exiftool file.jpg`
- Maltego: GUI tool (install from https://www.paterva.com/)
- SpiderFoot: `python3 sf.py -s scanname --target example.com`

## Notes:
- Most tools can be installed with: `pip3 install <toolname>` or `git clone ...`
- Requires: Python 3, Kali Linux or Debian-based OS

